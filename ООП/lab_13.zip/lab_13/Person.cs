﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace lab_13
{
    [Serializable]
    public class Person
    {
        public string Name { get; set; }
        public int Age { get; set; }

        public Person(string name, int age)
        {
            Name = name;
            Age = age;
        }

        public void Introduce()
        {
            Console.WriteLine($"Hello, my name is {Name} and I am {Age} years old.");
        }
    }

    [Serializable]
    public class Worker : Person
    {
        public string JobTitle { get; set; }
        public double Salary { get; set; }

        public Worker(string name, int age, string jobTitle, double salary)
            : base(name, age)
        {
            JobTitle = jobTitle;
            Salary = salary;
        }

        public void Work()
        {
            Console.WriteLine($"{Name} is working as a {JobTitle}.");
        }
    }
}
