﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.XPath;
using System.Xml;
using Newtonsoft.Json.Linq;

namespace lab_13
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // 1 ЗАДАНИЕ
            Console.WriteLine("1 ЗАДАНИЕ\n");
            Person person = new Person("Bob", 25);

            ISerializer serializer1 = new BinarySerializer(); // Можно заменить на любой другой сериализатор
            string filePath1 = "personBIN.bin";

            // Сериализация
            serializer1.Serialize(person, filePath1);

            // Десериализация
            Person deserializedPerson = serializer1.Deserialize<Person>(filePath1);
            Console.WriteLine($"Name: {deserializedPerson.Name}, Age: {deserializedPerson.Age}");
            //----------------------------------------------------------------------------------------------------

            // 2 ЗАДАНИЕ
            Console.WriteLine("\n2 ЗАДАНИЕ\n");

            List<Person> people = new List<Person>
            {
                new Person ("Alice",30 ),
                new Person ( "Bob", 28 ),
                new Person ("Charlie",35 )
            };

            ISerializer serializer2 = new JsonSerializer(); // Можно заменить на любой другой сериализатор
            string filePath2 = "people.json";

            // Сериализация
            serializer2.Serialize(people, filePath2);

            // Десериализация
            List<Person> deserializedPeopleJSON = serializer2.Deserialize<List<Person>>(filePath2);
            foreach (var p in deserializedPeopleJSON)
            {
                Console.WriteLine($"Name: {p.Name}, Age: {p.Age}");
            }
            //-----------------------------------------------------------------------------------------------------

            // 3 ЗАДАНИЕ

            Console.WriteLine("\n3 ЗАДАНИЕ\n");
            // Загружаем XML-документ
            XmlDocument doc = new XmlDocument();
            doc.Load("peopleXML.xml");

            // Создаем XPathNavigator для навигации по документу
            XPathNavigator navigator = doc.CreateNavigator();

            // XPath-селектор для выбора всех элементов <name>
            XPathNodeIterator nameNodes = navigator.Select("//name");
            Console.WriteLine("All <name> elements:");
            while (nameNodes.MoveNext())
            {
                Console.WriteLine(nameNodes.Current.Value);
            }

            // XPath-селектор для выбора элемента <person>, у которого <name> равно "Alice"
            XPathNodeIterator personNodes = navigator.Select("//person[name='Alice']");
            Console.WriteLine("\n<person> element with <name> 'Alice':");
            while (personNodes.MoveNext())
            {
                Console.WriteLine(personNodes.Current.OuterXml);
            }
            // -----------------------------------------------------------------------------------------

            // 4 ЗАДАНИЕ
            Console.WriteLine("\n4 ЗАДАНИЕ\n");
            // Создание JSON-документа
            JArray peopleArray = new JArray(
                new JObject(
                    new JProperty("Name", "Alice"),
                    new JProperty("Age", 30)
                ),
                new JObject(
                    new JProperty("Name", "Bob"),
                    new JProperty("Age", 25)
                ),
                new JObject(
                    new JProperty("Name", "Charlie"),
                    new JProperty("Age", 35)
                )
            );

            JObject peopleObject = new JObject(
                new JProperty("People", peopleArray)
            );

            Console.WriteLine(peopleObject.ToString());

            // Запросы к JSON-документу
            // 1. Выбор всех имен
            var names = peopleObject["People"].Select(p => p["Name"]).ToList();
            Console.WriteLine("\nAll names:");
            foreach (var name in names)
            {
                Console.WriteLine(name);
            }

            // 2. Выбор людей старше 30 лет
            var olderThan30 = peopleObject["People"].Where(p => (int)p["Age"] >= 30).ToList();
            Console.WriteLine("\nPeople older than 30:");
            foreach (var p in olderThan30)
            {
                Console.WriteLine(p);
            }

        }
    }
}
