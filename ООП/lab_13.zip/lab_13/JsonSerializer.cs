﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Text.Json;

namespace lab_13
{
    public class JsonSerializer : ISerializer
    {
        public void Serialize<T>(T obj, string filePath)
        {
            string jsonString = System.Text.Json.JsonSerializer.Serialize(obj);
            File.WriteAllText(filePath, jsonString);
        }

        public T Deserialize<T>(string filePath)
        {
            string jsonString = File.ReadAllText(filePath);
            return System.Text.Json.JsonSerializer.Deserialize<T>(jsonString);
        }
    }
}
